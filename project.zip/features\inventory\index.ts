export { InventoryPage } from './pages/InventoryPage';
