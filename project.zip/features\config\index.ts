export { ConfigPage } from './pages/ConfigPage';
